# Termux এ APK বিল্ড

1. Termux এ একবার চালান:  termux-setup-storage
2. জিপ আনজিপ করে প্রজেক্ট ফোল্ডারে ঢুকুন:
   cd ~ && mkdir -p StudyApp && cd StudyApp
   unzip -o ~/storage/downloads/Study_App_YTDL.zip
3. বিল্ড চালান:
   bash build_termux.sh
4. শেষে Download ফোল্ডারে StudyTracker.apk পাবেন, সেটা ইনস্টল করুন।

## নতুন ফিচার (yt-dlp ডাউনলোড)
- ভিডিও প্লেয়ারে Download বাটমে চাপলে "YT Downloader" পপআপ আসে।
- লিঙ্ক অটো বসানো থাকে; ফরম্যাট (1080p/720p/480p/MP3/M4A) বেছে Download চাপুন।
- ডাউনলোডের সময় লাইভ % ও MB/s স্পিড দেখায়।
- শেষে ভিডিও অ্যাপের ভেতরেই অফলাইনে সেভ হয় ও ExoPlayer এ চালু হয়।
- ডাউনলোড ফেল করলে পপআপের "Update yt-dlp (latest)" চাপুন।
- APK সাইজ বড় হবে (yt-dlp + python + ffmpeg থাকে), প্রথমবার ইঞ্জিন চালু হতে কয়েক সেকেন্ড লাগে।
- বিল্ডে RAM কম হলে build_termux.sh এ -Xmx2g কমিয়ে -Xmx1536m করুন।
